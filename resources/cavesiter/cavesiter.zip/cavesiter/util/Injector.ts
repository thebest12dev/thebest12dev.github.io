/*!
 * @file Injector.ts
 * @description A class that can perform deep property accessing, inject code into functions, apply injections, etc.
 * @version 0.1.0-alpha (u1)
 * 
 * Copyright (c) 2024 thebest12lines
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 * and associated documentation files (the "Software"), to deal in the Software without restriction,
 * including without limitation the rights to use, copy, modify, merge, publish, distribute,
 * sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or substantialportions of the Software.
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, 
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

export default class Injector {
    private targetObject = {}
    public apply: () => void = () => {
        console.warn("Error: This won't do anything unless for instances from the from() method.")
    }
    constructor(targetObject: object) {
        this.targetObject = targetObject
    }

    static from(object: any) {
        const injector = new Injector(object.injector.target)
        
        injector.apply = () => {
            try {
                object.injector.inject()
            } catch (e) {
                
                console.warn("Cavesiter inject failed; problems may occur during gameplay as some features were not modded!")
                object.injector.onError(e)
            }
            
           
        }
        return injector
    }
    assign(key: string, value: any) {
        const keys = key.split('.');
        let current: any = this.targetObject;
    
        for (let i = 0; i < keys.length - 1; i++) {
            if (!current[keys[i]]) {
                current[keys[i]] = {};
            }
            current = current[keys[i]];
        }
    
        current[keys[keys.length - 1]] = value;
    }
    get(path: string) {
        const keys = path.split('.');
        let current: any = this.targetObject;
    
        for (let key of keys) {
            if (current[key] === undefined) {
                return undefined;
            }
            current = current[key];
        }
    
        return current;
    }

    
    injectToFunction(key: string, inject: () => void, type: "before" | "after") {
       if (type == "after") {
            return () => {
                this.get(key)()
                inject()
            }
       } else if (type == "before") {
        return () => {
            inject()
            this.get(key)()
        }
       }
    }
    
}