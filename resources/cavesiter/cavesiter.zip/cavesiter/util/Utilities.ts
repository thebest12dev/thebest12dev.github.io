export default class Utilities {
    static isColor3(color: any): boolean {
        return color.r !== undefined && color.g !== undefined && color.b !== undefined;
    }
    static isColor4(color: any): boolean {
        return color.r !== undefined && color.g !== undefined && color.b !== undefined && color.a !== undefined;
    }
}