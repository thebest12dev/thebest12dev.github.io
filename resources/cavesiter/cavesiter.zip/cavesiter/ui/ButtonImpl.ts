import TextImpl from "./TextImpl";

export default class ButtonImpl extends TextImpl {
    setMouseDownHandler(handler: (event: MouseEvent) => void): void {
        this.element.onmousedown = handler;
    }
    setMouseUpHandler(handler: (event: MouseEvent) => void): void {
        this.element.onmouseup = handler;
    }
    setMouseEnterHandler(handler: (event: MouseEvent) => void): void {
        this.element.onmouseenter = handler;
    }
    setMouseLeaveHandler(handler: (event: MouseEvent) => void): void {
        this.element.onmouseleave = handler;
    }
    setMouseOverHandler(handler: (event: MouseEvent) => void): void {
        this.element.onmouseover = handler;
    }
    setClickHandler(handler: (event: MouseEvent) => void): void {
        this.element.onclick = handler;
    }
}