/*!
 * @file DOMUtilities.ts
 * @description Utility class for DOM-level manipulations.
 * @version 0.1.0-alpha (u1)
 * 
 * Copyright (c) 2024-2025 thebest12lines
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 * and associated documentation files (the "Software"), to deal in the Software without restriction,
 * including without limitation the rights to use, copy, modify, merge, publish, distribute,
 * sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, 
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
export default class DOMUtilities {
    static create(type: string): HTMLElement {
        if (type === 'label') {
            return document.createElement("span") as HTMLElement;
        } else if (type === 'button') {
            let btn = document.createElement("button")
            // apply _1 attribute for css selection
            btn.setAttribute("_1", "");
            return btn as HTMLElement;
        }
        return null as any;
    }
    static setParent(element: HTMLElement, childElement: HTMLElement): void {
        element.appendChild(childElement);
    }
    static setX(element: HTMLElement, x: number): void {
        element.style.left = x + 'px';
    }
    static setY(element: HTMLElement, y: number): void {
        element.style.top = y + 'px';
    }
    static setWidth(element: HTMLElement, width: number): void {
        element.style.width = width + 'px';
    }
    static setHeight(element: HTMLElement, height: number): void {
        element.style.height = height + 'px';
    }
    static setScale(element: HTMLElement, scale: number): void {
        element.style.transform = `scale(${scale})`;
    }
    static setText(element: HTMLElement, text: string): void {
        element.textContent = text;
    }
    static setTextColor(element: HTMLElement, color: string): void {
        element.style.color = color;
    }
    static setRotation(element: HTMLElement, rotation: number): void {
        element.style.transform = `rotate(${rotation}deg)`;
    }
    static setBackgroundColor(element: HTMLElement, color: string): void {
        element.style.backgroundColor = color;
    }
    static setBorderColor(element: HTMLElement, color: string): void {
        element.style.borderColor = color;
    }
}