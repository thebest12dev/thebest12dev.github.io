/*!
 * @file index.ts
 * @description The main entry point for the BlockJS client to run.
 * @version 0.1.0-alpha (u1)
 * 
 * Copyright (c) 2024 thebest12lines
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 * and associated documentation files (the "Software"), to deal in the Software without restriction,
 * including without limitation the rights to use, copy, modify, merge, publish, distribute,
 * sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, 
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

// too many imports
import Injectable from "../cavesiter/util/Injectable";
import CavesiterRendererAPI from "../cavesiter/modding/CavesiterRendererAPI";
import CavesiterRenderer from "../cavesiter/injectable/CavesiterRenderer";
import CavesiterConnection from "../cavesiter/injectable/CavesiterConnection";
import CavesiterConnectionAPI from "../cavesiter/modding/CavesiterConnectionAPI";
import Injector from "../cavesiter/util/Injector";
import Text from "./ui/Text";
import Button from "./ui/Button";
import ButtonImpl from "./ui/ButtonImpl";
import UIObjectImpl from "./ui/UIObjectImpl";
import UIObject from "./ui/UIObject";
import Label from "./ui/Label";
import TextImpl from "../cavesiter/ui/TextImpl";
import DOMUtilities from "./ui/DOMUtilities";
import Utilities from "./util/Utilities";
import Color3 from "./ui/Color3";
import Color4 from "./ui/Color4";
import Color from "./ui/Color";
import Authenticator from "./auth/Authenticator";
import CavesiterCredentials from "./auth/CavesiterCredentials";
import Screens from "./ui/Screens";
import Constants from "./util/Constants";
// inject to BlockJS
Injector.from(CavesiterRenderer.default).apply();
Injector.from(CavesiterConnection.default).apply();

window.addEventListener("beforeunload", () => {
    if (Constants.REVOKE_TOKEN_ON_RELOAD) {
        Authenticator.revokeSessionToken();
    }
});

(window as any).Cavesiter = {
    CavesiterConnection,
    CavesiterConnectionAPI, 
    CavesiterRenderer, 
    CavesiterRendererAPI,    
    Injector,
    Text,
    Button,
    ButtonImpl,
    UIObjectImpl,
    Label,
    TextImpl,
    DOMUtilities,
    Utilities,
    Color,
    Authenticator,
    Screens
}

console.log('%cCavesiter\n%c  Version 0.1.0            Initialized!\n\n\n\n\n\n%c', 'font-size: 80px;',"font-size:15px;", "font-size:12px");
console.log('\n\n\n\n\n\n%cSTOP!!!!!\n%cThis is a browser feature intended for developers. If someone told you to copy-paste something here to enable a feature or "hack" someone\'s account, it is a scam and will give them access to your account.\n\nLearn more about self-XSS: https://en.wikipedia.org/wiki/Self-XSS\n\n%c', 'font-size: 80px; color: red;', 'font-size: 20px; color: white;', 'font-size: 12px;');
export {
    CavesiterConnection,
    CavesiterConnectionAPI, 
    CavesiterRenderer, 
    CavesiterRendererAPI,    
    Injectable,
    Injector,
    Text,
    Button,
    ButtonImpl,
    UIObjectImpl,
    UIObject,
    Label,
    TextImpl,
    DOMUtilities,
    Utilities,
    Color3,
    Color4,
    Color,
    Authenticator,
    CavesiterCredentials,
    Screens
};