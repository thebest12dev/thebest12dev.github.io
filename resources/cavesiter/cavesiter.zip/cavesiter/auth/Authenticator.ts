import CavesiterCredentials from "./CavesiterCredentials";

export default class Authenticator {
    private static authServer = "";
    private static sessionToken = "";
    public static revokeSessionToken() {
        const url = this.authServer+"/cavesiter/apis/v1/revoke"



        const options = {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({token: Authenticator.sessionToken})
        };

        
        fetch(url, options)
            .then(response => response.json())
            .then(data => {
                Authenticator.sessionToken = "";
            })
            .catch((error) => {
                console.error('Error:', error);
            })

    }
    public static getSessionToken() {
        return Authenticator.sessionToken;
    }
    public static authenticate(credentials: CavesiterCredentials) {
        const url = this.authServer+"/cavesiter/apis/v1/authenticate"



        const options = {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(credentials)
        };

        
        fetch(url, options)
            .then(response => response.json())
            .then(data => {
                Authenticator.sessionToken = data.sessionToken;
            })
            .catch((error) => {
                console.error('Error:', error);
            })

    }
    public static setAuthenticationServer(url: URL | string) {
        this.authServer = "https://"+url.toString() //must be served over https
    }
}