export default class Constants {
    public static readonly VERSION = "0.1.0-alpha"; // version
    public static readonly BUILD = "u1"; // build
    public static readonly DEFAULT_AUTHENTICATION_SERVER = "cavesiter-auth.herokuapp.com"; // auth server to use
    public static readonly ENFORCE_LOCAL_COOKIES = false; // note: this is a security risk
    public static readonly REVOKE_TOKEN_ON_RELOAD = true; // note: this is a security risk
    public static readonly SHOW_HUD = true; // show HUD
    public static readonly LOG_LEVEL = 1; // possible options: INFO, DEBUG, WARN, ERROR
    public static readonly LOG_TO_CONSOLE = true; // log to console
    public static readonly USE_AUTHENTICATION = true; // use authentication
}