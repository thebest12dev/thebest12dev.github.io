/*!
 * @file CavesiterConnection.ts
 * @description The injectable WebSocket code to add Cavesiter-specific properties.
 * @version 0.1.0-alpha (u1)
 * 
 * Copyright (c) 2024 thebest12lines
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 * and associated documentation files (the "Software"), to deal in the Software without restriction,
 * including without limitation the rights to use, copy, modify, merge, publish, distribute,
 * sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, 
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

import Injectable from "../../cavesiter/util/Injectable";
import CavesiterConnectionAPI from "../../cavesiter/modding/CavesiterConnectionAPI";
// connection inject
export default class CavesiterConnection implements Injectable {
    injector = {
        inject() {
        },
        onError(e: Error) {
            // don't do anything for now
        },
        target: (window as any).BlockJS
    }   
    private static instance = new CavesiterConnection() // singleton
    public static get default() : CavesiterConnection {
        return CavesiterConnection.instance; // singleton
    }
    
}