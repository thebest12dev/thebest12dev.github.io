/*!
 * @file Color.ts
 * @description A utility class for color manipulation.
 * @version 0.1.0-alpha (u1)
 * 
 * Copyright (c) 2024-2025 thebest12lines
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 * and associated documentation files (the "Software"), to deal in the Software without restriction,
 * including without limitation the rights to use, copy, modify, merge, publish, distribute,
 * sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, 
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

import Color3 from "./Color3";
import Color4 from "./Color4";
export default class Color {
    static fromRGB(r: number, g: number, b: number): Color3 {
        return { r: r, g: g, b: b };
    }
    static fromHex(hex: string): Color3 {
        // Remove the # prefix if it exists
        if (hex.startsWith('#')) {
            hex = hex.slice(1);
        }

        // Convert hex to RGB
        const r = parseInt(hex.substring(0, 2), 16);
        const g = parseInt(hex.substring(2, 4), 16);
        const b = parseInt(hex.substring(4, 6), 16);

        return { r: r, g: g, b: b };
    }
    static fromCSSColor(name: string): Color3 {
        const canvas = document.createElement('canvas');
        canvas.width = canvas.height = 1;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
            throw new Error('Could not create 2D canvas context');
        }
        ctx.fillStyle = name;
        ctx.fillRect(0, 0, 1, 1);
        const data = ctx.getImageData(0, 0, 1, 1).data;
        return { r: data[0], g: data[1], b: data[2] };
    }
    static fromColor3(color: Color3): Color3 {
        return { r: color.r, g: color.g, b: color.b };
    }
    static toColor4(color: Color3, a: number = 1): Color4 {
        return { r: color.r, g: color.g, b: color.b, a: a };
    }
    static fromRGBA(r: number, g: number, b: number, a: number): Color4 {
        return { r: r, g: g, b: b, a: a };
    }
    static toColor3(color: Color4): Color3 {
        return { r: color.r, g: color.g, b: color.b };
    }
    static fromColor4(color: Color4): Color4 {
        return { r: color.r, g: color.g, b: color.b, a: color.a };
    }

}