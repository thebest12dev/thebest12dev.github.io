/*!
 * @file Text.ts
 * @description Builder class for rich text manipulation.
 * @version 0.1.0-alpha (u1)
 * 
 * Copyright (c) 2024-2025 thebest12lines
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 * and associated documentation files (the "Software"), to deal in the Software without restriction,
 * including without limitation the rights to use, copy, modify, merge, publish, distribute,
 * sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, 
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
import Color3 from "./Color3";

export default class Text {
    private text: string;
    private rawText: string;

    constructor(text: string) {
        this.text = text;
        this.rawText = text;
    }

    static fromLiteral(str: string): Text {
        return new Text(str);
    }

    static fromText(text: Text): Text {
        return new Text(text.toString());
    }

    // string(): string {
    //     return this.text;
    // }

    // use toString for polymorphism
    toString(): string {
        return this.text;
    }
    // Method overloads for bold
    bold(): Text;
    bold(start: number, end: number): Text;

    // Single implementation for all overloads
    bold(start?: number, end?: number): Text {
        if (start !== undefined && end !== undefined) {
            const boldText = this.rawText.substring(start, end);
            const boldedText = "<b>" + boldText + "</b>";
            const newText = this.text.replace(boldText, boldedText);
            return new Text(newText);
        } else {
            return new Text("<b>" + this.text + "</b>");
        }
    }

    // Method overloads for italic
    italic(): Text;
    italic(start: number, end: number): Text;

    // Single implementation for all overloads
    italic(start?: number, end?: number): Text {
        if (start !== undefined && end !== undefined) {
            const italicText = this.rawText.substring(start, end);
            const italicizedText = "<i>" + italicText + "</i>";
            const newText = this.text.replace(italicText, italicizedText);
            return new Text(newText);
        } else {
            return new Text("<i>" + this.text + "</i>");
        }
    }

    // Method overloads for color
    color(color: Color3): Text;
    color(color: Color3, start: number, end: number): Text;

    // Single implementation for all overloads
    color(color: Color3, start?: number, end?: number): Text {
        if (start !== undefined && end !== undefined) {
            const colorText = this.rawText.substring(start, end);
            const coloredText = `<span style="color: rgb(${color.r}, ${color.g}, ${color.b})">${colorText}</span>`;
            const newText = this.text.replace(colorText, coloredText);
            return new Text(newText);
        } else {
            return new Text(`<span style="color: rgb(${color.r}, ${color.g}, ${color.b})">${this.text}</span>`);
        }
    }

    // Method overloads for underline
    underline(): Text;
    underline(start: number, end: number): Text;

    // Single implementation for all overloads
    underline(start?: number, end?: number): Text {
        if (start !== undefined && end !== undefined) {
            const underlineText = this.rawText.substring(start, end);
            const underlinedText = "<u>" + underlineText + "</u>";
            const newText = this.text.replace(underlineText, underlinedText);
            return new Text(newText);
        } else {
            return new Text("<u>" + this.text + "</u>");
        }
    }

    raw(): Text {
        // Remove all HTML tags
        const rawString = this.text.replace(/<\/?[^>]+(>|$)/g, "");
        return new Text(rawString);
    }
}