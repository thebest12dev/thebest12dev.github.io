export default class Shaders {
    public static readonly vertexShader = `#version 300 es

        // Vertex Shader
        in float vShowBorder;  
        in float vBorderWidth;
        in vec3 vertPosition;
        in float aTextureIndex;
        in vec2 aTextureCoord;
        in vec3 instancePosition;
        in vec3 instanceScale;
        
        
        uniform mat4 viewMatrix;
        uniform mat4 projectionMatrix;
        out float fShowBorder;  // Output to fragment shader
        out float fBorderWidth;  // Output to fragment shader
        out highp vec2 vTextureCoord;
        flat out int vTextureIndex;
        in float aShowBorder; // Unused but used in fragment shader
        
        void main() {
            // Apply instance scale and position
            vec3 scaledPosition = vertPosition * instanceScale;
            vec4 worldPosition = vec4(scaledPosition + instancePosition, 1.0);
        
            // Transform to clip space
            gl_Position = projectionMatrix * viewMatrix * worldPosition;
            
            // Pass texture coordinates to the fragment shader
            vTextureCoord = aTextureCoord;
            vTextureIndex = int(aTextureIndex); // Pass the texture index to the fragment shader
            fShowBorder = vShowBorder;
        }
    `;
    
    public static readonly fragmentShader = `#version 300 es
precision mediump float;

in highp vec2 vTextureCoord;
in float fShowBorder;
flat in int vTextureIndex;
uniform mediump sampler2DArray uSamplers;
uniform vec3 uFogColor;
uniform float uFogStart;
uniform float uFogEnd;

out vec4 outColor;

vec4 applyFog(vec4 color, float depth) {
    float fogFactor = clamp((depth - uFogStart) / (uFogEnd - uFogStart), 0.0, 1.0);
    return mix(color, vec4(uFogColor, 1.0), fogFactor);
}

void main() {
    // Use texture array and index directly
    vec4 texColor = texture(uSamplers, vec3(vTextureCoord, vTextureIndex));

    float depth = gl_FragCoord.z / gl_FragCoord.w;
    vec4 finalColor = applyFog(texColor, depth);

    if (fShowBorder == 1.0) {
        ivec2 texSize = textureSize(uSamplers, 0).xy;
        vec2 distToEdge = min(vTextureCoord, 1.0 - vTextureCoord) * vec2(texSize);
        if (any(lessThan(distToEdge, vec2(0.25)))) {
            finalColor = vec4(0.0, 0.0, 0.0, 1.0);
        }
    }

    outColor = finalColor;
}
    `
}