type CavesiterCredentials = {
    username: string,
    password?: string,
    token?: string
}

export default CavesiterCredentials;