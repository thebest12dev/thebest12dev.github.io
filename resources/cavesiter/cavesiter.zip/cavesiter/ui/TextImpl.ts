/*!
 * @file TextImpl.ts
 * @description An implementation/mixin for text-related manipulation.
 * @version 0.1.0-alpha (u1)
 * 
 * Copyright (c) 2024-2025 thebest12lines
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 * and associated documentation files (the "Software"), to deal in the Software without restriction,
 * including without limitation the rights to use, copy, modify, merge, publish, distribute,
 * sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, 
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

import Utilities from "../util/Utilities";
import Color3 from "./Color3";
import Color4 from "./Color4";
import Text from "./Text";
import UIObjectImpl from "./UIObjectImpl";

export default class TextImpl extends UIObjectImpl{
    setText(text: Text | string): void {
        this.element.textContent = text.toString();
    }
     setTextColor(color: Color3 | Color4): void {
          if (Utilities.isColor3(color)) {
              this.element.style.color = "rgb(" + color.r + "," + color.g + "," + color.b + ")";
          } else if (Utilities.isColor4(color)) {
              this.element.style.color = "rgba(" + color.r + "," + color.g + "," + color.b + "," + (color as Color4).a + ")";
          }
     }
     setFontSize(size: number): void {
         this.element.style.fontSize = size + "px";
     }
     setFontFamily(family: string): void {
         this.element.style.fontFamily = family;
     }
     setFontStyle(style: string): void {
         this.element.style.fontStyle = style;
     }
     setFontWeight(weight: string): void {
         this.element.style.fontWeight = weight;
     }
     setFontVariant(variant: string): void {
         this.element.style.fontVariant = variant;
     }
     setLineHeight(height: number): void {
         this.element.style.lineHeight = height + "px";
     }
     setLetterSpacing(spacing: number): void {
         this.element.style.letterSpacing = spacing + "px";
     }
     setTextAlign(align: string): void {
         this.element.style.textAlign = align;
     }
     setTextDecoration(decoration: string): void {
         this.element.style.textDecoration = decoration;
     }
     setTextTransform(transform: string): void {
         this.element.style.textTransform = transform;
     }
     setWhiteSpace(whiteSpace: string): void {
         this.element.style.whiteSpace = whiteSpace;
     }
     setWordSpacing(spacing: number): void {
         this.element.style.wordSpacing = spacing + "px";
     }
     setWordWrap(wrap: string): void {
         this.element.style.wordWrap = wrap;
     }
     setCursor(cursor: string): void {
         this.element.style.cursor = cursor;
     }
}