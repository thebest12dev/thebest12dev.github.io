import Constants from './Constants'

export default class Logger {
    private instance: any
    private logs: Array<object> = []
    getLogger() {
        if (!this.instance) {
            this.instance = new Logger()
        }
        return this.instance
    }
    info(message: string, context: string | null = null) {
        this.logs.push({level: "INFO", message, context});
        if (Constants.LOG_TO_CONSOLE && Constants.LOG_LEVEL > 1) {
            console.log(`[INFO] [${context}] ${message}`);
        }
    }
    error(message: string, context: string | null = null) {
        this.logs.push({level: "ERROR", message, context});
        if (Constants.LOG_TO_CONSOLE && Constants.LOG_LEVEL > 3) {
            console.error(`[ERROR] [${context}] ${message}`);
        }
    }
    warn(message: string, context: string | null = null) {
        this.logs.push({level: "WARN", message, context});
        if (Constants.LOG_TO_CONSOLE && Constants.LOG_LEVEL > 2) {
            console.warn(`[WARN] [${context}] ${message}`);
        }
    }
    debug(message: string, context: string | null = null) {
        this.logs.push({level: "DEBUG", message, context});
        if (Constants.LOG_TO_CONSOLE && Constants.LOG_LEVEL > 4) {
            console.debug(`[DEBUG] [${context}] ${message}`);
        }
    }

    getLogs() {
        return this.logs;
    }
}