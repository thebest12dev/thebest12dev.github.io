This file contains useful information that is used for
archives at compile time as it can be used to find lost
versions if the creator did not archive them.

NOTE: Some versions are internally archived, so only the
creator can access these builds. These are prefixed with
`internal_` and should not be accessed.

***********************************************************
Cavesiter build: 0.2.1r (commit 1 of u8)
Compiled: 01/19/2025 10:37:28 PM (UTC+6)
Language: typescript
Target platform: BlockJS ^931c551a9
Compiled by: thebest12lines
Author: thebest12lines
***********************************************************
Total SLOC: ~3400
Total source size (compressed): ~90kb
***********************************************************
Changelog:
    - Added downloads
    - Added IPFS links for updating
    - Added technical details